[![E+E_Logo](./images/epluse-logo.png)](https://www.epluse.com/en/)

# Basis of E2 communication with Arduino


## QUICK START GUIDE  


| Step |                                                                                                                                                             |
|------|-------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1    | Download and install the Arduino IDE (https://www.arduino.cc/en/software). Version >1.8.7 recommended.                         |
| 2    | Download the ZIP File of this project.|
| 3    | Open the arduino software.|
| 4    | Go to: <br>[<img src="images/add_library.png" width="550"/>](images/add_library.png) |
| 5    | Search for the downloaded ZIP File and open it.|



## License 
See [LICENSE](LICENSE).